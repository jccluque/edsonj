clc,clear;
close all;

opts1 = detectImportOptions('vectoresyorch.csv');
VectorNAV = readtable('vectoresyorch.csv',opts1);

opts2 = detectImportOptions('motores.csv');
Motors = readtable('motores.csv',opts2);

% calculo Velocidad
a11=zeros(length((VectorNAV.yaw)),1);a12=zeros(length((VectorNAV.yaw)),1);a13=zeros(length((VectorNAV.yaw)),1);
b11=zeros(length((VectorNAV.yaw)),1);b12=zeros(length((VectorNAV.yaw)),1);b13=zeros(length((VectorNAV.yaw)),1);
c11=zeros(length((VectorNAV.yaw)),1);c12=zeros(length((VectorNAV.yaw)),1);c13=zeros(length((VectorNAV.yaw)),1);
VelBody=zeros(3,1,length((VectorNAV.yaw)));v=zeros(3,1,length((VectorNAV.yaw)));J=zeros(3,3,length((VectorNAV.yaw)));Jt=zeros(3,3,length((VectorNAV.yaw)));

for i=1:length((VectorNAV.yaw))

% CALCULO MATRIZ J
      a11(i,1) = cos (VectorNAV.yaw(i,1)) * cos (VectorNAV.pitch(i,1));
      a12(i,1) = (cos (VectorNAV.yaw(i,1)) * sin (VectorNAV.pitch(i,1)) * sin (VectorNAV.yaw(i,1))) - (sin (VectorNAV.yaw(i,1)) * cos (VectorNAV.roll(i,1)));
      a13(i,1) = (sin (VectorNAV.yaw(i,1)) * sin (VectorNAV.roll(i,1)) - cos (VectorNAV.yaw(i,1)) * cos (VectorNAV.roll(i,1)) * sin (VectorNAV.pitch(i,1)));

      b11(i,1) = sin (VectorNAV.yaw(i,1)) * cos (VectorNAV.pitch(i,1));
      b12(i,1) = (cos (VectorNAV.roll(i,1)) * cos (VectorNAV.pitch(i,1))) + (sin (VectorNAV.roll(i,1)) * sin (VectorNAV.pitch(i,1)) * sin (VectorNAV.yaw(i,1)));
      b13(i,1) = (cos (VectorNAV.roll(i,1)) * sin (VectorNAV.pitch(i,1)) * sin (VectorNAV.yaw(i,1)) - cos (VectorNAV.yaw(i,1)) * sin (VectorNAV.roll(i,1)));

      c11(i,1) = -sin (VectorNAV.pitch(i,1));
      c12(i,1) = cos (VectorNAV.pitch(i,1)) * sin (VectorNAV.roll(i,1));
      c13(i,1) = cos (VectorNAV.roll(i,1)) * cos (VectorNAV.pitch(i,1));

J(:,:,i)=[a11(i,1) a12(i,1) a13(i,1); b11(i,1) b12(i,1) b13(i,1); c11(i,1) c12(i,1) c13(i,1)];
Jt(:,:,i)=inv(J(:,:,i));

% MATRIZ DE VELOCIDAD NED
v(:,:,i)=[VectorNAV.velocityx(i,1);VectorNAV.velocityy(i,1);VectorNAV.velocityz(i,1)];

% CALCULO VELOCIDAD BODY
VelBody(:,:,i) = Jt(:,:,i)* v(:,:,i);

end

% arreglo de YAW
for i=2:length(Motors.Yaw) 
   a1=Motors.Yaw(i)-Motors.Yaw(i-1);
      if  a1 > 340
            Motors.Yaw(i) = Motors.Yaw(i) - 360;
      end

      if  a1 < -340
            Motors.Yaw(i) = Motors.Yaw(i) + 360;
      end
          
end
figure
plot(Motors.time_1,Motors.Yaw);

grid on;
title('YAW');
    xlabel('Time (Hours:Minutes)');
    ylabel('Yaw (Deg)');
    legend('Yaw');


VelXBody=zeros(length((VectorNAV.yaw)),1);
VelYBody=zeros(length((VectorNAV.yaw)),1);
VelZBody=zeros(length((VectorNAV.yaw)),1);
for i=1:length((VectorNAV.yaw))
        VelXBody(i)=VelBody(1,1,i);
        VelYBody(i)=VelBody(2,1,i);
        VelZBody(i)=VelBody(3,1,i);
end 

for i=1:length((Motors.LeftMotor))
        Motors.RightMotor(i)=round(Motors.RightMotor(i) * 0.7874);
        Motors.LeftMotor(i)=round(Motors.LeftMotor(i) * 0.7874);
end 

% limites
zz=5;
ANGULO=-123.1;
Limsup=(ANGULO-zz)*ones(length(Motors.Yaw),1);
Liminf=(ANGULO+zz)*ones(length(Motors.Yaw),1);

Limsup1=(ANGULO-2*zz)*ones(length(Motors.Yaw),1);
Liminf1=(ANGULO+2*zz)*ones(length(Motors.Yaw),1);
Limsup2=(ANGULO-3*zz)*ones(length(Motors.Yaw),1);
Liminf2=(ANGULO+3*zz)*ones(length(Motors.Yaw),1);
Limsup3=(ANGULO-4*zz)*ones(length(Motors.Yaw),1);
Liminf3=(ANGULO+4*zz)*ones(length(Motors.Yaw),1);
Limsup4=(ANGULO-5*zz)*ones(length(Motors.Yaw),1);
Liminf4=(ANGULO+5*zz)*ones(length(Motors.Yaw),1);
Limsup5=(ANGULO-6*zz)*ones(length(Motors.Yaw),1);
Liminf5=(ANGULO+6*zz)*ones(length(Motors.Yaw),1);
% MANIOBRAS ZIGZAGS CON GPS

figure
plot(Motors.time_1,Motors.Yaw,'LineWidth', 2)
hold on;
grid on;
plot(Motors.time_1,Motors.LeftMotor,'r','LineWidth', 2)
plot(Motors.time_1,Motors.RightMotor,'k','LineWidth', 2)
plot(Motors.time_1,Limsup,'--','color','r');
plot(Motors.time_1,Liminf,'--','color','r');

plot(Motors.time_1,Limsup1,'--','color','k');
plot(Motors.time_1,Liminf1,'--','color','k');

plot(Motors.time_1,Limsup2,'--','color','g');
plot(Motors.time_1,Liminf2,'--','color','g');

plot(Motors.time_1,Limsup3,'--','color','b');
plot(Motors.time_1,Liminf3,'--','color','b');

plot(Motors.time_1,Limsup4,'--','color','y');
plot(Motors.time_1,Liminf4,'--','color','y');

plot(Motors.time_1,Limsup5,'--','color','c');
plot(Motors.time_1,Liminf5,'--','color','c');
    title('YAW and Motors PWM porcent Value ');
    xlabel('Time (Hours:Minutes)');
    ylabel('Yaw, PWM Porcent (Deg, %)');
    legend('Yaw','Left Motor','Right Motor','5 deg','10 deg','15 deg','20 deg','25 deg','30 deg');
    
    
    
% VELOCIDAD
figure
plot(VectorNAV.time_1,VelXBody,'LineWidth', 2);
grid on;
hold on;
plot(VectorNAV.time_1,VelYBody,'r','LineWidth', 2);
plot(VectorNAV.time_1,VelZBody,'k','LineWidth', 2);
title('Velocity X,Y,Z in Body');
legend('Velocity in Body Axis X','Velocity in Body Axis Y','Velocity in Body Axis Z');
ylabel('Velocity (m/s)');
xlabel('Time (Seconds)');